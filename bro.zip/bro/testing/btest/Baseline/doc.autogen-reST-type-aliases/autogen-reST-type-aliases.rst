.. Automatically generated.  Do not edit.

:tocdepth: 3

autogen-reST-type-aliases.bro
=============================




:Source File: :download:`autogen-reST-type-aliases.bro`

Summary
~~~~~~~
State Variables
###############
======================================= =======================================================
:bro:id:`a`: :bro:type:`TypeAlias`      But this should reference a type of ``TypeAlias``.

:bro:id:`b`: :bro:type:`OtherTypeAlias` And this should reference a type of ``OtherTypeAlias``.
======================================= =======================================================

Types
#####
============================================ ==========================================================================
:bro:type:`TypeAlias`: :bro:type:`bool`      This is just an alias for a builtin type ``bool``.

:bro:type:`OtherTypeAlias`: :bro:type:`bool` We decided that creating alias "chains" might not be so useful to document
                                             so this type just creates a cross reference to ``bool``.
============================================ ==========================================================================

Detailed Interface
~~~~~~~~~~~~~~~~~~
State Variables
###############
.. bro:id:: a

   :Type: :bro:type:`TypeAlias`

   But this should reference a type of ``TypeAlias``.

.. bro:id:: b

   :Type: :bro:type:`OtherTypeAlias`

   And this should reference a type of ``OtherTypeAlias``.

Types
#####
.. bro:type:: TypeAlias

   :Type: :bro:type:`bool`

   This is just an alias for a builtin type ``bool``.

.. bro:type:: OtherTypeAlias

   :Type: :bro:type:`bool`

   We decided that creating alias "chains" might not be so useful to document
   so this type just creates a cross reference to ``bool``.

