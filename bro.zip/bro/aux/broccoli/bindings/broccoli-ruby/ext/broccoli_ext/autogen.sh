#!/bin/sh

swig -ruby `broccoli-config --cflags` broccoli_intern.i 
