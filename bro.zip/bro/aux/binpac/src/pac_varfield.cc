#include "pac_varfield.h"

void PrivVarField::Prepare(Env *env)
	{
	Field::Prepare(env);
	}
